package component;

import java.io.*;
import java.net.*;
import java.util.*;

public class FileServer {
    private static final int PORT = 12345;
    private static Set<ClientHandler> clients = Collections.synchronizedSet(new HashSet<>());

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("✅ FileServer chạy tại port " + PORT);

            while (true) {
                Socket socket = serverSocket.accept();
                ClientHandler clientHandler = new ClientHandler(socket);
                clients.add(clientHandler);
                new Thread(clientHandler).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Gửi file tới tất cả client khác
    public static void broadcastFile(String sender, String fileName, byte[] fileData, ClientHandler self) {
        synchronized (clients) {
            for (ClientHandler client : clients) {
                if (client != self) {
                    client.sendFile(sender, fileName, fileData);
                }
            }
        }
    }

    // Class xử lý client
    static class ClientHandler implements Runnable {
        private Socket socket;
        private DataInputStream dis;
        private DataOutputStream dos;
        private String username;

        public ClientHandler(Socket socket) {
            try {
                this.socket = socket;
                this.dis = new DataInputStream(socket.getInputStream());
                this.dos = new DataOutputStream(socket.getOutputStream());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void run() {
            try {
                // Nhận username từ client
                username = dis.readUTF();
                System.out.println("👤 " + username + " đã kết nối: " + socket.getInetAddress());

                while (true) {
                    String fileName = dis.readUTF();
                    long fileSize = dis.readLong();

                    File dir = new File("server_files");
                    if (!dir.exists()) dir.mkdir();

                    File file = new File(dir, fileName);
                    FileOutputStream fos = new FileOutputStream(file);

                    byte[] buffer = new byte[4096];
                    long remaining = fileSize;
                    int bytesRead;
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();

                    while (remaining > 0 &&
                           (bytesRead = dis.read(buffer, 0, (int) Math.min(buffer.length, remaining))) != -1) {
                        fos.write(buffer, 0, bytesRead);
                        baos.write(buffer, 0, bytesRead);
                        remaining -= bytesRead;
                    }
                    fos.close();

                    System.out.println("📥 " + username + " gửi file: " + fileName);

                    // Gửi tới các client khác
                    FileServer.broadcastFile(username, fileName, baos.toByteArray(), this);
                }
            } catch (IOException e) {
                System.out.println("❌ Mất kết nối với " + username);
            } finally {
                try { socket.close(); } catch (IOException ignored) {}
                clients.remove(this);
            }
        }

        public void sendFile(String sender, String fileName, byte[] fileData) {
            try {
                dos.writeUTF(sender);
                dos.writeUTF(fileName);
                dos.writeLong(fileData.length);
                dos.write(fileData);
                dos.flush();
            } catch (IOException e) {
                System.out.println("⚠️ Lỗi gửi file tới " + username);
            }
        }
    }
}
