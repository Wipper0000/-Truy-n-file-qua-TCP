package component;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.Socket;

public class ChatClient extends JFrame {
    private JButton chooseButton, sendButton;
    private JLabel selectedFileLabel, statusLabel;
    private DefaultListModel<String> chatModel;
    private JList<String> chatList;
    private File selectedFile;
    private Socket socket;
    private DataOutputStream dos;
    private DataInputStream dis;
    private String username;
    private JProgressBar progressBar;

    public ChatClient(String serverAddress, int port, String username) {
        this.username = username;

        // Giao diện hệ thống
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        setTitle("📡 File Chat - " + username);
        setSize(650, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 245, 255));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));

        // ====== MENU ======
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem disconnectItem = new JMenuItem("Ngắt kết nối");
        JMenuItem exitItem = new JMenuItem("Thoát");

        disconnectItem.addActionListener(e -> disconnect());
        exitItem.addActionListener(e -> System.exit(0));

        fileMenu.add(disconnectItem);
        fileMenu.add(exitItem);
        menuBar.add(fileMenu);
        setJMenuBar(menuBar);

        // ====== CHAT LIST ======
        chatModel = new DefaultListModel<>();
        chatList = new JList<>(chatModel);
        JScrollPane scrollPane = new JScrollPane(chatList);
        scrollPane.setBorder(BorderFactory.createTitledBorder("💬 Lịch sử gửi file"));

        // Render màu tin nhắn
        chatList.setCellRenderer((list, value, index, isSelected, cellHasFocus) -> {
            JLabel label = new JLabel(value);
            if (value.startsWith("Bạn:")) {
                label.setForeground(new Color(34, 139, 34)); // xanh lá
            } else {
                label.setForeground(new Color(128, 0, 128)); // tím
            }
            if (isSelected) {
                label.setOpaque(true);
                label.setBackground(new Color(220, 220, 250));
            }
            return label;
        });

        // ====== PROGRESS BAR ======
        progressBar = new JProgressBar();
        progressBar.setStringPainted(true);

        // ====== PANEL DƯỚI ======
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(new Color(230, 230, 250));

        JPanel buttonPanel = new JPanel();
        chooseButton = new JButton("📂 Chọn file");
        sendButton = new JButton("📤 Gửi");
        sendButton.setEnabled(false);
        buttonPanel.add(chooseButton);
        buttonPanel.add(sendButton);

        selectedFileLabel = new JLabel("Chưa chọn file nào");
        selectedFileLabel.setForeground(Color.DARK_GRAY);

        statusLabel = new JLabel("⏳ Chưa kết nối");
        statusLabel.setForeground(Color.BLUE);

        bottomPanel.add(buttonPanel, BorderLayout.WEST);
        bottomPanel.add(selectedFileLabel, BorderLayout.CENTER);
        bottomPanel.add(statusLabel, BorderLayout.SOUTH);

        // ====== ADD VÀO FRAME ======
        panel.add(progressBar, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(bottomPanel, BorderLayout.SOUTH);
        add(panel);

        // ====== ACTION ======
        chooseButton.addActionListener(e -> chooseFile());
        sendButton.addActionListener(e -> {
            if (selectedFile != null) {
                sendFile(selectedFile);
            }
        });

        chatList.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    String item = chatList.getSelectedValue();
                    if (item != null && item.contains(": ")) {
                        String fileName = item.substring(item.indexOf(": ") + 2);
                        try {
                            Desktop.getDesktop().open(new File("received/" + fileName));
                        } catch (Exception ex) {
                            JOptionPane.showMessageDialog(null, "Không mở được file!");
                        }
                    }
                }
            }
        });

        // ====== KẾT NỐI SERVER ======
        connectToServer(serverAddress, port);
    }

    private void chooseFile() {
        JFileChooser fileChooser = new JFileChooser();
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            selectedFile = fileChooser.getSelectedFile();
            selectedFileLabel.setText("Đã chọn: " + selectedFile.getName());
            sendButton.setEnabled(true);
        }
    }

    private void connectToServer(String serverAddress, int port) {
        try {
            socket = new Socket(serverAddress, port);
            dos = new DataOutputStream(socket.getOutputStream());
            dis = new DataInputStream(socket.getInputStream());

            // Gửi username
            dos.writeUTF(username);
            statusLabel.setText("✅ Đã kết nối: " + serverAddress + ":" + port);

            // Thread nhận file
            new Thread(() -> {
                try {
                    while (true) {
                        String sender = dis.readUTF();
                        String fileName = dis.readUTF();
                        long fileSize = dis.readLong();

                        File dir = new File("received");
                        if (!dir.exists()) dir.mkdir();

                        File file = new File(dir, fileName);
                        FileOutputStream fos = new FileOutputStream(file);

                        byte[] buffer = new byte[4096];
                        long remaining = fileSize;
                        int bytesRead;
                        long received = 0;

                        progressBar.setMaximum((int) fileSize);
                        while (remaining > 0 &&
                                (bytesRead = dis.read(buffer, 0, (int) Math.min(buffer.length, remaining))) != -1) {
                            fos.write(buffer, 0, bytesRead);
                            remaining -= bytesRead;
                            received += bytesRead;
                            progressBar.setValue((int) received);
                        }
                        fos.close();

                        chatModel.addElement(sender + ": " + fileName);
                        progressBar.setValue(0);
                    }
                } catch (IOException e) {
                    statusLabel.setText("❌ Mất kết nối");
                }
            }).start();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "❌ Không thể kết nối server!");
            System.exit(1);
        }
    }

    private void sendFile(File file) {
        try {
            dos.writeUTF(file.getName());
            dos.writeLong(file.length());

            FileInputStream fis = new FileInputStream(file);
            byte[] buffer = new byte[4096];
            int bytesRead;
            long sent = 0;
            progressBar.setMaximum((int) file.length());

            while ((bytesRead = fis.read(buffer)) != -1) {
                dos.write(buffer, 0, bytesRead);
                sent += bytesRead;
                progressBar.setValue((int) sent);
            }
            fis.close();

            chatModel.addElement("Bạn: " + file.getName());
            selectedFileLabel.setText("Chưa chọn file nào");
            sendButton.setEnabled(false);
            progressBar.setValue(0);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "⚠️ Lỗi gửi file!");
        }
    }

    private void disconnect() {
        try {
            if (socket != null) socket.close();
            statusLabel.setText("🔌 Đã ngắt kết nối");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "⚠️ Lỗi khi ngắt kết nối!");
        }
    }

    public static void main(String[] args) {
        String username = JOptionPane.showInputDialog("Nhập tên của bạn:");
        if (username == null || username.trim().isEmpty()) {
            System.exit(0);
        }
        SwingUtilities.invokeLater(() -> {
            new ChatClient("127.0.0.1", 12345, username).setVisible(true);
        });
    }
}
